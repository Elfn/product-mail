package com.pm.productMail;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductMailApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductMailApplication.class, args);
	}

}
